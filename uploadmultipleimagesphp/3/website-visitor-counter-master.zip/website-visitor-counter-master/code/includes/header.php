<!DOCTYPE html>
<html>
	<head>
		<title>Website Visitor Counter</title>
	</head>
	
	<body>
		<header>
			<ul>
				<li><a href="index.php">Main Page</a></li>
				<li><a href="page_1.php">Page 1</a></li>
				<li><a href="page_2.php">Page 2</a></li>
				<li><a href="page_3.php">Page 3</a></li>
			</ul>
		</header>