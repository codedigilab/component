# Website Visitor Counter
Simple Website Visitor Counter Using PHP &amp; MySQL

# Installation Instructions
1- Open phpMyAdmin.

2- Create a database named "website_visitor_counter" and then import the SQL file "website_visitor_counter.sql" that is placed inside "database" folder of this project.

3- Now open "index.php" file that is placed inside "code" folder.

# Step-by-Step Tutorial
Link: https://www.edopedia.com/blog/how-to-create-website-visitor-counter-php-mysql/
