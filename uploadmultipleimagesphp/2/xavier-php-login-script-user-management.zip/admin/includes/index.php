<?php
// Yikes
