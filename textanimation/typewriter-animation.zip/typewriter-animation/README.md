# Typewriter Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/imedeli/pen/gOJoJON](https://codepen.io/imedeli/pen/gOJoJON).

This Codepen showcases a typewriter animation using only CSS. The animation simulates the effect of text being written letter by letter, as if written by a typewriter.