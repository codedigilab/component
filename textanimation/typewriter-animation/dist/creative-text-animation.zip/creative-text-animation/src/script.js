/*the complete project is in the following link:
https://github.com/vkive/CSS-Creative-Text-Animation-Effects.git
Follow me on Codepen
*/